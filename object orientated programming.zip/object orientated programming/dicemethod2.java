/**
 * @(#)dicemethod2.java
 *
 *
 * @author 
 * @version 1.00 2012/10/15
 */


public class dicemethod2 {

    public static void main(String args[]) {
    	System.out.println("Time to use the method");
    	roll_dice(10); // method call which passes the value of 10 onto the method
    	System.out.println("I used this mehtd to roll the dice");
    }
    public static void roll_dice(int x){
    	for (int i =0;i<x;i++) {
    		System.out.println (1+ (int) (Math.random()*6));
    	}//end for
    }//end roll method
    
}