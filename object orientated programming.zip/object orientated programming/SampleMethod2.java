/**
 * @(#)SampleMethod2.java
 *
 *
 * @author 
 * @version 1.00 2012/10/18
 */


public class SampleMethod2 {

    public static void main(String args[]) {
    	
    	//variables to recieve the result returned by the method
    	int result = 0;

    	System.out.println ("Time to use the method");
    	
    	//method call
    	result=roll_dice(10);
    		
    	System.out.println ("the sum of all the dice added is " + result);
    	
    }// end main method
    
    public static int roll_dice(int x){
    	
    	int sum=0;
    	int dice;
    	
    	for (int i =0;i<x;i++) {
    		dice =(1+(int)(Math.randm()*6));
    		sum =sum+dice;
    	}//end for loop
    	
    	
    	//sebd num back to method call
    	return sum;
    }//end roll_dice method
}//end class