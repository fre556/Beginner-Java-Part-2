/**
 * @(#)sampleMethod.java
 *
 *
 * @author 
 * @version 1.00 2012/10/18
 */


public class sampleMethod {

    public static void main (String args[]) {
    	System.out.println ("Time to use the method");
    	
    	//method call
    	roll_dice (10,3);
    	
    	System.out.println ("The method rolled a dice");
    	
    }//end main method
    
    public static void roll_dice(int x,int y){
    	
    	for (int i=0;i<x;i++) {
    		System.out.println (1 + (int)(Math.random()*y));
    	}//end for
    }//end method roll_dice
    
    
}