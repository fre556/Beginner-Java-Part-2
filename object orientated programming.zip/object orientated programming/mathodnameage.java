/**
 * @(#)mathodnameage.java
 *
 *
 * @author 
 * @version 1.00 2012/10/18
 */


public class mathodnameage {

    public static void main (String args[]) {
    	
    	String name ="ciaran";
    	int age =21;
    	
    	//declare variables
    	printname(name);
    	printage(age);
    	printnameage(name,age);
    		
    	
    }//end main
    
    public static void printname(String x) {
    	System.out.println (x);
    }//end printname method   
    
    public static void printage(int y){
    	System.out.println (y);
    }//end printage method
    public static void printnameage (String x , int y){
    	System.out.println ("My name is " + x + "\nMy age is " + y);
    }
    
}//end class 