/**
 * @(#)namelengthmethod.java
 *
 *
 * @author 
 * @version 1.00 2012/10/22
 */

import java.util.Scanner;
public class namelengthmethod {

    public static void main (String args[]) {
    	
    	Scanner input = new Scanner(System.in);
    		
    	String firstname;
    	
    	System.out.print ("Enter name: ");
    	firstname=input.next();
    	
    	name(firstname);
    	
    	System.out.print ("you have  " + name(firstname) + " characters in your name" );
    }//end main
    public static int name(String x) {
    	
  
    		return(x.length());
    	
    	
    }//end method

    
    
}//end class