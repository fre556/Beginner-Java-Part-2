/**
 * @(#)passinganumber.java
 *
 *
 * @author 
 * @version 1.00 2012/11/5
 */

import java.util.Scanner;
public class passinganumber {

    public static void main (String args[]) {
    	
    	Scanner input = new Scanner(System.in);
    	
    	int number;
    	
    	System.out.print ("Enter number: ");
    	number=input.nextInt();
    	
    	passnumber(number);
    }//end nain method
    
    public static void passnumber(int x) {
    	
    	for (int i=0;i<=x;x--) {
    		System.out.print (x);
    	}//end for
    }//end method
    
    
}//end class