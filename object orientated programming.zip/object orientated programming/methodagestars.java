/**
 * @(#)methodagestars.java
 *
 *
 * @author 
 * @version 1.00 2012/10/18
 */

import java.util.Scanner;
public class methodagestars {

    public static void main (String args[]) {
    	
    	Scanner input = new Scanner (System.in);
    	int age;
    	
    	System.out.println ("Enter age:");
    	age=input.nextInt();
    	
    	agestars(age);   	

    	}//ebd main method
    	
    public static void agestars(int x) {
    	
    	
	    for (int i = 0;i<x;i++) {
	    		System.out.println("*");
   		 }//end for loop
     
    	
    }//end age stars method
    
    
}//end class