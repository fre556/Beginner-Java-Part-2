/**
 * @(#)rolldicemethod.java
 *
 *
 * @author 
 * @version 1.00 2012/10/15
 */


public class rolldicemethod {

    public static void main (String args[]){
    	
    	System.out.println ("allabout the method");
    	//method call
    	roll_dice();
    	System.out.println("The method was called");
    	

    }
    public static void roll_dice(){
    	System.out.println (1+ (int)(Math.random()*6));
    	}//end roll dice method
    
    
}