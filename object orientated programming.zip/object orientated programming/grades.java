/**
 * @(#)grades.java
 *take in 3 grades and use a method to add them 
 *validation must be donr on all inputs
 *
 * @author 
 * @version 1.00 2012/11/5
 */

import java.util.Scanner;
public class grades {
	static Scanner input = new Scanner(System.in);
    public static void main(String args[]) {
    	
    	
    	
    	int grades[]=new int[3];
    	int total, result;
    	String strgrade;
    	
    5
    	//pass the grades to a method to add them
    	int addition = add(grades); //this pass the whole array to the method
    	System.out.println ("All grades totaled " + addition);
    	
    }//end main
    
    public static int validate(String x,int z) {
    	
    	
    	while (!x.matches("\\d+")) {
    		System.out.print ("Error ,numbers only");
    		System.out.print("Enter grade " + (z+1) + " : ");
    		x=input.next();
    	}//end while
    	
    	int val = Integer.parseInt(x);
    	return val;
    }//end method
    
    public static int add(int array[]) {
    	
    	int total=0;
    	
    	for (int i=0;i<array.length;i++) {
    		total += array[i];
    	}//end for
    	return total;
    }//end method
}//end class