/**
 * @(#)MethodArrays.java
 * Pass an array to a method and get the average age.
 * Return the age.
 *
 * @ Philip Corbally 
 * @version 1.00 2012/11/8
 */


public class MethodArrays {

    public static void main(String args[]) {
    	
    	int ages[] = {20,29,19,24,18};
    	int result;
    	
    	//passing down the ages array, no need for the '[]'
    	result = averageage(ages);
    	
    	System.out.println("The average age is: " + result);
    	
    }//end main method
    
    
    public static int averageage(int arrayx[]){	//taking in an array - use '[]' here
    
    	int total = 0;
    	
    	for(int i=0;i<arrayx.length;i++){
    		total += arrayx[i];
    	}//end for loop
    	
    	return total/5;
    	
    }//end averageage method
    
    
}//end class