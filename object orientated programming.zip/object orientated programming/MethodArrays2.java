/**
 * @(#)MethodArrays2.java
 * Take in 5 3-digit pins and store them in an array.
 * Pass each entry to a method to check it contains only 3 digits. ("\\d{3}")
 *
 * @ Philip Corbally
 * @version 1.00 2012/11/8
 */

import java.util.Scanner;
public class MethodArrays2 {
	
static Scanner input = new Scanner(System.in);

    public static void main(String args[]) {
    	
    	int pins[] = new int[5];
    	
   		String strpin;
   		
   		for(int i=0;i<pins.length;i++){
   			System.out.print("Enter pin " + (i+1) + ": ");
   			strpin = input.next();
   			
   			//method call
   			pins[i] = validatepin(strpin, i);
   			
   		}//end for
   		
   		System.out.println("The pins are:\n\nSubscript\tPIN\n");
   		
   		for(int i=0;i<pins.length;i++){
   			System.out.println(i + "\t\t\t" + pins[i]);
   		}//end for
   		
    }//end main method
    
    
    public static int validatepin(String x, int z){
    	
    	while(!x.matches("\\d{3}")){
    		System.out.println("Error");
    		System.out.print("Enter pin " + (z+1) + ": ");
   			x = input.next();
    	}//end while loop
    	
    	int valpin = Integer.parseInt(x);
    	
    	return valpin;
    	
    }//end validatepin method
    
}//end class