/**
  @(#)nameagemethod.java
 *pass your name and age to a method
 *The method will print your name and print a star for every year old you are
 *
 * @author 
 * @version 1.00 2012/10/22
 */


public class nameagemethod {

    public static void main (String args[]) {

    	String name = "BOb";
    	int age = 20;
    	
    	name_age(name,age);

    
    	
    	}//end main	
    public static void name_age(String x,int y) {
    	System.out.print ("Good evening" + x);
    	
    	for (int i=0;i<y;i++){
    		System.out.print ("*");
    	}
    } 
    
    
    
}//end class