/**
 * @(#)helloworld.java
 *
 *
 * @author 
 * @version 1.00 2012/10/18
 */


public class helloworld {

    public static void main (String args[]) {
    	System.out.println ("about to call the method");
    	hello_world();
    	System.out.println ("the method said hello");
    }
    public static void hello_world() {
    
    
    System.out.println ("hello world");
    }
    
}