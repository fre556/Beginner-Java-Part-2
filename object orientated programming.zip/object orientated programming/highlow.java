/**
 * @(#)highlow.java
 *take in 5 grades and store them in array
 *get the highest and lowest grade
 *print the subscript of the highest grade
 *
 * @author 
 * @version 1.00 2012/10/4
 */

import java.util.Scanner;
public class highlow {

    public static void main (String args[]) {
    
    	Scanner input = new Scanner (System.in());
    
    	int grade[]=new int [5];
    	int i, highest=0, lowest = 100,highsub,;
    	
    	for (i=0;i<grade.length;i++) {
    		
    		System.out.print ("enter grade " + (i+1) + ":");
    		grade[i]=input.nextInt(); 
    		
    		if (grade[i]<lowest) {
    			lowest=grade[i];  			
    		}//end if
    		if (grade[i]>highest) {
    			highest=grade[i];
    			//hold onto subscript
    			highsub=i;    			
    		}
    		
    	}
    	System.out.println ("the highest grade is " + highest );
    	System.out.println ("the lowest grade is " + lowest );
    	System.out.println ("the highest grade position grade is " + highsub );
    }
    
    
}