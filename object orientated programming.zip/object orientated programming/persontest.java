/**
 * @(#)persontest.java
 *
 *
 * @author 
 * @version 1.00 2012/12/6
 */


public class persontest {

    public static void main(String agrs[]) {
    	
    	person per1=new person("ciaran",21,"Dublin");
    	
    	System.out.println(per1.toString());
    	
    	System.out.println(per1.talk("Blah blah blah"));
    	
    	//create new person instance of person
    	person invalid = new person ("",-1,"Meath");
    	
    	System.out.println(invalid.toString());
    	
    }//end main
    
    
}//