/**
 * @(#)methodEg3.java
 *pass a number to a method
 *the method will add the square of the numbers
 *from  1 to the number passed down
 *the method will send  the answer back to the method call
 *
 * @author 
 * @version 1.00 2012/10/22
 */


public class methodEg3 {

    public static void main(String args[]) {
    	

    	int result=0;
  		
  		//method call
  		result = square(20);
  		
  		System.out.println ("The result is " + result);
    	      	
    	
    }//end main
    
    public static int square(int x) {
		
		int total=0;
    	
    	for (int i=1;i<x;i++) {

    		total += (i*i);
    	}//end for
    	
    	return total;

    	
    }//end square method
    
    
}//end class