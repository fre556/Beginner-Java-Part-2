/**
 * @(#)person.java
 *
 *
 * @author 
 * @version 1.00 2012/12/6
 */


public class person {
	
	private String name;
	private int age;
	private String address;

    public person(String n,int a,String add) {
    	if (n.length()>0){
    		name=n;
    	}//end if
    	else{
    		name= "unknown";
    	}
    	age=((a>0)?a:0);
    	address=add;
    	}//end constructer
    public  String talk(String x){
    	return name +"says"+x;
    }
    public String toString(){
    	return "Name : " + name + "\nAge: " + age + "\nAddress : " + address;
    }
    
    
}