/**
 * @(#)Method5AgesError.java
 * Take in 5 ages. Check for non-digits in a method.
 * Get youngest and oldest in main method.
 * Pass the youngest and oldest to a method called difference.
 * Get the difference between oldest and youngest and pass back the result.
 *
 * @ Philip Corbally 
 * @version 1.00 2012/11/8
 */

import java.util.Scanner;
public class Method5AgesError {

//declare scanner globally so it can be used in all methods
static Scanner input = new Scanner(System.in);

    public static void main(String args[]) {
    	
    	int age, oldest =0, youngest = 200, average, total = 0, i, result;
    	String strage;
    	
    	//loop to take in ages
    	for(i=1;i<6;i++){
    		System.out.print("Enter age " + i + ": ");
    		strage = input.next();
    		
    		//method call
    		age = validate(strage,i);
    		
    		total += age;
    		
    		//check for highest and lowest
    		if(age > oldest){
    			oldest = age;
    		}//end if
    		
    		if(age < youngest){
    			youngest = age;
    		}//end if
    		
    	}//end for loop
    	
    	average = total/5;
    	
    	//method call for difference between youngest and oldest
    	result = difference(oldest, youngest);
    	
    	System.out.println();
    	System.out.println("The average age is: " + average);
    	System.out.println();
    	System.out.println("The difference between the oldest and youngest age is: " + result);
    	
    }//end main method
    
    
    public static int validate(String x, int y){
    	
    	int num;
    	
    	while(!x.matches("\\d+")){
    		System.out.println("Error - numbers only");
    		System.out.print("Enter age " + y + ": ");
    		x = input.next();
    	}//end while
    	
    	num = Integer.parseInt(x);
    	return num;
    	
    }//end validate method
    
    
    public static int difference(int x, int y){
    	
    	return x - y;
    	
    }//end difference method
    
}//end class