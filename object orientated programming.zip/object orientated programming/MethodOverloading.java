/**
 * @(#)MethodOverloading.java
 * 
 *
 * @ Philip Corbally
 * @version 1.00 2012/11/8
 */


public class MethodOverloading {

    public static void main(String args[]) {
    	
    	int num1=5, num2=10, num3=15;
    	
    	//method call to add with 2 int arguments
    	add(num1, num2);
    	
    	//method call to add with 3 int arguments
    	add(num1, num2, num3);
    	
    	//method call to add 2 string arguments
    	add("Philip ", "Corbally");
    	
    }//end main method
    
    
    public static void add(int x, int y){
    	System.out.println("The two numbers added equal: " + (x+y));
    }//end add method
    
    
    public static void add(int x, int y, int z){
    	System.out.println("The two numbers added equal: " + (x+y+z));
    }//end add method
    
    public static void add(String x, String y){
    	System.out.println(x+y);
    }//end add method
    
}//end class