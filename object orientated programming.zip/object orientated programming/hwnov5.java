/**
 * @(#)hwnov5.java
 *Homework
 *take in 5 ages. check for non digits in a seperate method
 *get the youngest ,oldest and average age in the main method
 *
 *pass the youngest and oldest age to a method called differences 
 *which will return the difference between the youngest and oldest age
 * @author 
 * @version 1.00 2012/11/5
 */

import java.util.Scanner;
public class hwnov5 {
	static Scanner input = new Scanner(System.in);
    public static void main (String args[]) {
    	
    	int age[]=new int[5];
    	int oldest,youngest,result;
    	
    	String strage;
    	
    		//take in the grades
    	for (int i=0;i<age.length;i++) {
    		System.out.print ("Enter grade " + (i+1) + " : ");
    		 strage= input.next();
    		
    		//method to validate
    		result= validate(strage,i);
    		age[i]=result;
    		
    		//if statement for oldest and youngest
    		if (age[i]<youngest) {
    			youngest=age[i];  			
    		}//end if
    		if (age[i]>oldest) {
    			oldest=age[i];
    		
    		}//end if
    		
    	}//ends for
    	
    	//pass age and minus the 2 ages for the difference
    	difference(oldest,youngest);
    	minus(age[i]);
    	System.out.println ("The difference beteen the ages are " + minus(age[i]) );
    		
    	
    	
    }// end main
    
		public static int validate(String x,int z) {
		    	
		    	
		    while (!x.matches("\\d+")) {
		    	System.out.print ("Error ,numbers only");
		    	System.out.print("Enter grade " + (z+1) + " : ");
		    	x=input.next();
		    }//end while
		    	
		    int val = Integer.parseInt(x);
		    return val;
		    }//end method
		    
		 public static int difference(int x,int y) {
    	
	    	return x-y;
	    }//end method
}// end class]
