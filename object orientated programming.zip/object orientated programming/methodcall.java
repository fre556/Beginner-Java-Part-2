/**
 * @(#)methodcall.java
 *
 *
 * @author 
 * @version 1.00 2012/10/22
 */


public class methodcall {

    public static void main (String args[]) {
    	
    	
    	name();
    		
    }//end main
    
    public static void name(){
    	System.out.println ("My name is mr henry");
    }//end main
    
    
}//end class