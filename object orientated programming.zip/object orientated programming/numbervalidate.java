/**
 * @(#)numbervalidate.java
 *
 *take a number for the user and use the method to square it
 *and send the result back
 *
 * @author 
 * @version 1.00 2012/10/25
 */

import java.util.Scanner;
public class numbervalidate {
static Scanner input = new Scanner (System.in);
    public static void main(String args[]) {
    	
    	String strnum;
    	int result,answer;
    	
    	//prompt user
		System.out.print ("Enter number to square: ");
		strnum=input.next(); //declare as string
		
		//method call
		result = validate(strnum);
		
		//method call to square number
		answer = squarenum(result);
		
		System.out.println (result + "squared is " + answer);		    	
    }//end main
    
    public static int validate (String x) {
    	 int num,result;
;
    	 
    	 while (!x.matches("\\d+")) {
    	 	System.out.print ("Error,numbers only");
    	 	
    	 	System.out.print ("Enter number to square: ");
			x=input.next(); //declare as reenter
    	 }//end while
    	
    	//change reenter to an int
    	num = Integer.parseInt(x);
    	return num;
    }//end validate method
    
    public static int squarenum(int x) {
    	return x*x;
    }//end 
    
    
    
    
}//end class