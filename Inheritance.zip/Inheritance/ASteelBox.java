/**
 * @(#)ASteelBox.java
 *
 *
 * @author Graham Jordan
 * @version 1.00 2013/1/31
 */


public class ASteelBox extends ABox{

    public ASteelBox(int w, int h) {
    	super(w,h);
    	
    }//end asteelbox
    
    public String toString(){
    	
    	return "This is a steel box\nWidth: " + Getwidth() + "\nheight: " + Getheight();
    }//end toString
    
}//end class