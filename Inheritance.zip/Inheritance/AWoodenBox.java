/**
 * @(#)AWoodenBox.java
 *
 *
 * @author Graham Jordan
 * @version 1.00 2013/1/31
 */


public class AWoodenBox extends ABox {
	
	private String woodtype;

    public AWoodenBox(int w, int h, String wt) {
    	super(w,h);
    	woodtype = wt;
    	
    }
    
    public String toString(){
    	return "This is a wooden box\nWidth: " + Getwidth() + "\nHeight: " + Getheight() + "\nWood Type: " + woodtype;
    }
    
    
}