/**
 * @(#)ABoxTest2.java
 *
 *
 * @author 
 * @version 1.00 2013/1/31
 */


public class ABoxTest2 {

    public static void main(String args[]) {
    	ABox b[] = new ABox[3];
    	
    	b[0] = new ABox(2,3);
    	b[1] = new ASteelBox(5,3);
    	b[2] = new AWoodenBox(2,3, "Pine");
    	
    	for(int i = 0; i<3 ; i++){
    		System.out.println("\n" + b[i].toString());
    		
    	}
    	
    }//end main method
    
    
}//end class