/**
 * @(#)ABox.java
 *example of inheritance
 *
 * @author graham jordan
 * @version 1.00 2013/1/31
 */


public class ABox {
	
	private int width, height;
	

    public ABox(int w, int h) {
    	
    	width = ((w>0)?w:0);
    	height = ((h>0)?h:0);
    }//end constructor
    
    public int Getwidth(){
    	return width;
    }//end getwidth
    public int Getheight(){
    	return height;
    }//end getheight
    
    public String toString(){
    	return "This is a single box\nWidth: " + width + "\nHeight: " + height;
    	
    }//end toString
    
    
}//end class