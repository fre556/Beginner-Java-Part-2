/**
 * @(#)ABoxTest.java
 *
 *
 * @author 
 * @version 1.00 2013/1/31
 */


public class ABoxTest {

    public static void main(String args[]) {
    	ABox b1 = new ABox(2,3);
    	
    	ASteelBox sb = new ASteelBox(2,6);
    	
    	AWoodenBox wb = new AWoodenBox(4,3,"Pine");
    	
    	System.out.println(b1 + "\n\n" + sb + "\n\n" + wb);
    	
    }//end main method
    
    
}