/**
 * @(#)basepluscommissiontest.java
 *
 *
 * @author 
 * @version 1.00 2013/2/4
 */


public class basepluscommissiontest {

    public static void main (String args[]) {  
    	basepluscommissionemployee employee = new basepluscommissionemployee( "Bob", "Lewis", "333-33-3333", 5000, .04, 300 );             
         
         System.out.println("Employee information obtained by get methods: \n" );
         System.out.println("First name is");
         employee.getfirstname();
         System.out.println("last name is");
         employee.getlastname();
         System.out.println("social security number is");
         employee.getsocialsecuritynumber();
         System.out.println("gross sales is");
         employee.getgrosssales();
         System.out.println("commission rate is");
         employee.getcommissionrate();
         System.out.println("base salary is");
         employee.getbasesalary();
         
         System.out.printf( "\n%s:\n\n%s\n","Updated employee information obtained by toString",employee.toString() );
           
           

         
           
    

	
    }
    
    
}