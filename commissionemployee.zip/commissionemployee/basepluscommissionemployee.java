/**
 * @(#)basepluscommissionemployee.java
 *
 *
 * @author 
 * @version 1.00 2013/2/4
 */


public class basepluscommissionemployee extends commissionemployee3 {
	private double basesalary;
    public basepluscommissionemployee(String first, String last,String ssn,double sale,double rate,double salary){
    
    	 
   		super( first, last, ssn, sale, rate );
   		setbasesalary( salary );   
    }//end basepluscommissionemployee
    
    public void setbasesalary( double salary ){
    
        basesalary = ( salary < 0.0 ) ? 0.0 : salary;
     } // end method setBaseSalary

     // return base salary
     public double getbasesalary(){
     
        return basesalary;
    } // end method getBaseSalary

     // calculate earnings
     public double earnings() {    
      	 return getbasesalary() + super.earnings();
     } // end method earnings
  

     // return String representation of BasePlusCommissionEmployee4
     public String toString()
     {
       return String.format( "%s %s\n%s: %.2f", "base-salaried",
           super.toString(), "base salary", getbasesalary() );   
     } // end method toString

     
     
     

    
    
    
}