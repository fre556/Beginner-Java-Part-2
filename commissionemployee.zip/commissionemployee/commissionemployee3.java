/**
 * @(#)commissionemployee3.java
 *
 *
 * @author 
 * @version 1.00 2013/2/4
 */


public class commissionemployee3 {
	//declare variables
	private String firstname;
	private String lastname;
	private String socialsecuritynumber;
	private double grosssales;
	private double commissionrate;
    
    public commissionemployee3(String fm,String lm,String ssn, double gs,double cr) {
    	firstname = fm;
        lastname = lm;
        socialsecuritynumber = ssn;
        setgrosssales( gs ); 
        setcommissionrate( cr ); 
    	
    }
    public void setFirstName( String fm )
     {
        firstname = fm;
     } // end method setFirstName
     public String getfirstname(){
   
      return firstname;
   } // end method getFirstName
   public void setlastname( String lm )
     {
        lastname=lm;
     } // end method setFirstName
     public String getlastname(){
   
      return lastname;
   } // end method getFirstName
   public void setsocialsecuritynumber( String ssn )
     {
        socialsecuritynumber=ssn;
     } // end method setFirstName
     public String getsocialsecuritynumber(){
   
      return socialsecuritynumber;
   } // end method getFirstName
   
   public void setgrosssales( double sales )
    {
       grosssales = ( (sales < 0.0 ) ? 0.0 : sales);
   } // end method setGrossSales
   public double getgrosssales()
   {
       return grosssales;
    } // end method getGrossSales
    
    public void setcommissionrate( double rate )
  {
       commissionrate = ( (rate > 0.0 && rate < 1.0 ) ? rate : 0.0);
   } // end method setCommissionRate
   
   public double getcommissionrate()
   {
       return commissionrate;
    } // end method getcommissionrate
    
    public double earnings()
    {
       return getcommissionrate() * getgrosssales();
    } // end method earnings
    
    public String toString()
    {
       return String.format( "%s: %s %s\n%s: %s\n%s: %.2f\n%s: %.2f",
          "commission employee", getfirstname(), getlastname(),
          "social security number", getsocialsecuritynumber(),
          "gross sales", getgrosssales(),
          "commission rate", getcommissionrate() );
     } // end method toString
  } // end class CommissionEmployee3







   

   


    
    
